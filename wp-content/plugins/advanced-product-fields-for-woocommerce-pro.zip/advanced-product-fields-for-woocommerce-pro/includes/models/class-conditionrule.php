<?php

namespace SW_WAPF_PRO\Includes\Models {

    if (!defined('ABSPATH')) {
        die;
    }

    class ConditionRule
    {

        public $subject;

        public $condition;

        public $value;
    }

}