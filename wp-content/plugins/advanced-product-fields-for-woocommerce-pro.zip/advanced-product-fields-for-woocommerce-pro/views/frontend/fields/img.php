<?php  ?>

<img src="<?php echo $model['field_value']; ?>" <?php echo $model['field_attributes']; ?> />