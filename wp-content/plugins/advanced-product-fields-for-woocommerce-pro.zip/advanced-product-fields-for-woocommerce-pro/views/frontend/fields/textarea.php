<?php
?>
<textarea <?php echo $model['field_attributes']; ?>><?php echo $model['field_value']; ?></textarea>
