<?php  ?>
<div class="wapf-duplicate-group <?php echo esc_html($model['field']->options['slug']); ?>"
     data-gtitle="<?php echo isset($model['field']->options['title']) ? esc_html($model['field']->options['title']) : ''; ?>">
</div>