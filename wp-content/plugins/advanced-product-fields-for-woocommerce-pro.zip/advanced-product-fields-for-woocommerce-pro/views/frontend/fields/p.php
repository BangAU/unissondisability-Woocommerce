<?php
?>
<div <?php echo $model['field_attributes']; ?>>
	<?php echo do_shortcode($model['field_value']); ?>
</div>
