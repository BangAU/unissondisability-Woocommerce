<?php
?>

<input type="number" value="<?php echo $model['field_value']; ?>" <?php echo $model['field_attributes']; ?> />
