<?php
?>

<input type="text" value="<?php echo $model['field_value']; ?>" <?php echo $model['field_attributes']; ?> />